(() => {
  const form = document.getElementById('solarForm');
  if (!form) return;

  const number = id => Number(document.getElementById(id).value);
  const format = value => new Intl.NumberFormat('en-IN', { maximumFractionDigits: 1 }).format(value);
  const money = value => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);

  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;

    const units = number('units');
    const generation = number('generation');
    const cost = number('cost');
    const existing = number('existing');
    if (![units, generation, cost, existing].every(Number.isFinite) || units <= 0 || generation <= 0 || cost <= 0 || existing < 0) return;

    const rawAdditional = Math.max(0, (units / generation) - existing);
    const additional = rawAdditional === 0 ? 0 : Math.ceil(rawAdditional * 2) / 2;
    const totalCapacity = existing + additional;
    const monthlyGeneration = totalCapacity * generation;
    const result = document.getElementById('result');

    result.innerHTML = `
      <span class="eyebrow">YOUR ESTIMATE</span>
      <h2>${format(additional)} kW</h2>
      <p>Suggested additional solar capacity</p>
      <div class="result-row"><span>Total capacity including existing</span><b>${format(totalCapacity)} kW</b></div>
      <div class="result-row"><span>Estimated monthly generation</span><b>${format(monthlyGeneration)} units</b></div>
      <div class="result-row"><span>Indicative cost for new capacity</span><b>${money(additional * cost)}</b></div>
      <div class="result-row"><span>Estimated annual generation</span><b>${format(monthlyGeneration * 12)} units</b></div>
      <p class="small">Planning estimate only. Actual output and price depend on site conditions and final system design.</p>`;
  });
})();
